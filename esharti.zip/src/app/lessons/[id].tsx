import React, { Suspense } from "react";
import { SingleLesson, SingleLessonSkeleton } from "../../features/lessons";
import Container from "../../components/Container";

const Lesson = () => {
  return (
    <Container
      showBottomTabs={false}
      topSafeAreaViewColor="#F5F5F5"
      bottomSafeAreaViewColor="#F5F5F5"
    >
      <Suspense fallback={<SingleLessonSkeleton />}>
        <SingleLesson />
      </Suspense>
    </Container>
  );
};

export default Lesson;
