import { TouchableOpacity } from "react-native";
import Container from "../components/Container";
import { ArrowLeftIcon, ShareIcon } from "../components/SvgIcons";
import { View } from "../components/custom/View";
import {
  SingleLiveEvent,
  SingleLiveEventSkeleton,
} from "../features/liveEvent";
import { Suspense } from "react";
import { router } from "expo-router";

export default function LiveEvent() {
  return (
    <Container
      showBottomTabs={false}
      topSafeAreaViewColor="#F5F5F5"
      bottomSafeAreaViewColor="#F5F5F5"
    >
      <View className="flex-row items-center justify-between mx-[18px] my-[23px]">
        <View>
          <ShareIcon />
        </View>
        <TouchableOpacity onPress={() => router.replace("/")}>
          <ArrowLeftIcon />
        </TouchableOpacity>
      </View>
      <Suspense fallback={<SingleLiveEventSkeleton />}>
        <SingleLiveEvent />
      </Suspense>
    </Container>
  );
}
