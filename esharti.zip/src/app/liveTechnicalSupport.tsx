import VideoCameraIcon from "../assets/icons/VideoCameraIcon.svg";
import ArrowLeftIcon from "../assets/icons/ArrowLeftIcon.svg";
import { Text } from "../components/custom/Text";
import { View } from "../components/custom/View";
import Container from "../components/Container";
import { ScrollView, TouchableOpacity } from "react-native";
import PlanList from "../features/liveTechnicalSupport/components/PlanList";

import { router } from "expo-router";

export default function liveTechnicalSupport() {
  return (
    <Container showBottomTabs={false} bottomSafeAreaViewColor="#F5F5F5">
      <View className="h-[91px] bg-white px-[22] py-[28px] flex-row items-center justify-between">
        <View className="flex-row items-center gap-x-[9px]">
          <VideoCameraIcon
            height={29}
            width={29}
            strokeWidth={1.8}
            stroke={"#040404"}
          />
          <Text className="text-[22px]">خدمة الدعم الفني المباشر</Text>
        </View>
        <TouchableOpacity onPress={() => router.replace("/")}>
          <ArrowLeftIcon />
        </TouchableOpacity>
      </View>
      <ScrollView automaticallyAdjustKeyboardInsets>
        <View className="my-[29px] px-layout bg-[#F5F5F5] relative">
          <Text className="text-[#525252] text-[18px] px-[3px]">
            تطبيق "اشارتي" يوفر لك الفرصة للتواصل المباشر واللحظي مع متخصصي لغة
            الإشارة، الذين يمكنهم مساعدتك في حل المشكلات على الفور. سواء كنت
            بحاجة إلى استشارة فنية، أو ترجمة فورية، أو حتى دورات تعليمية، فإن
            خدمة الدعم الفني المباشر في تطبيق "اشارتي" توفر لك الحل السريع
            والفعال.
          </Text>
          <Text className="text-[#525252] text-[18px] px-[3px] mt-5">
            استمتع بتجربة تفاعلية سلسة وفعالة مع متخصصي لغة الإشارة، مما يضمن
            تقديم خدماتك وتطبيقك بشكل أكثر شمولية واحترافية. انضم إلى مجتمع
            "اشارتي" وجعل تجربة الاتصال أكثر سهولة وفعالية للجميع.
          </Text>
          <PlanList />
        </View>
      </ScrollView>
    </Container>
  );
}
