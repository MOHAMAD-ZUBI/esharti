import { BottomSheetModalProvider } from "@gorhom/bottom-sheet";
import Container from "../components/Container";
import TopBar from "../components/TopBar";
import NotificationBottomSheet from "../components/NotificationBottomSheet";
import { ScrollView } from "react-native";
import {
  SuggestedCoursesList,
  SuggestedCoursesSkeleton,
} from "../features/courses";
import { LatestArticlesList } from "../features/articles";
import { LiveTechnicalSupportCard } from "../features/liveTechnicalSupport";
import { Suspense, useEffect } from "react";
import { View } from "../components/custom/View";
import { Text } from "../components/custom/Text";
import { TouchableOpacity } from "react-native-gesture-handler";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { useAuth } from "../context/AuthContext";
import { useBottomSheet } from "../features/bottomSheet";
import * as Notifications from "expo-notifications";
import { LiveEventList } from "../features/liveEvent";
import useProfile from "../features/account/hooks/useProfile";
import { API } from "../lib/client";
import { authRoutes } from "../routes";
import NationalIdBottomSheet from "../components/NationalIdBottomSheet";
export default function HomeScreen() {
  const { bottomSheetRef, close, open } = useBottomSheet();
  const {
    bottomSheetRef: NationalIdBottomSheetRef,
    close: closeNationalIdBottomSheet,
    open: openNationalIdBottomSheet,
  } = useBottomSheet();
  const { data } = useProfile();

  useEffect(() => {
    const getDeviceTokenAsync = async () => {
      // ask for Permissions to send notifications
      const { status: existingStatus } =
        await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;
      if (existingStatus !== "granted") {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }
      if (finalStatus !== "granted") {
        return;
      }
      const { data: device_token } =
        await Notifications.getDevicePushTokenAsync();
      try {
        await API.post(authRoutes.registerDeviceToken, { device_token });
      } catch (error) {}
    };
    if (data && data?.device_token === null) {
      getDeviceTokenAsync();
    }
  }, []);

  useEffect(() => {}, []);
  const { session } = useAuth();
  return (
    <>
      <Container topSafeAreaViewColor="#F5F5F5">
        <ScrollView className="bg-[#F5F5F5]">
          <TopBar openNotificationBottomSheet={open} />
          <Suspense>
            <LiveEventList />
          </Suspense>
          <LiveTechnicalSupportCard subscribed={true} />
          {/**** Suggested courses section ****/}
          <View className="mt-[27px]">
            <View className="flex-row mx-layout justify-between items-center">
              <Text>دورات مقترحة</Text>
              <TouchableOpacity
                onPress={() => router.push("/courses/")}
                className="flex-row gap-[0.5px]"
              >
                <Text className="text-[#FEC433]">جميع الدورات</Text>
                <Feather name="arrow-left" size={24} color="#FEC433" />
              </TouchableOpacity>
            </View>
            <Suspense fallback={<SuggestedCoursesSkeleton />}>
              <SuggestedCoursesList />
            </Suspense>
          </View>
          {/**** latest articles section ****/}
          <LatestArticlesList />
        </ScrollView>
      </Container>

      {session?.authenticated && (
        <NotificationBottomSheet bottomSheetRef={bottomSheetRef} />
      )}
      {session?.authenticated && (
        <NationalIdBottomSheet
          bottomSheetRef={NationalIdBottomSheetRef}
          closeNationalIdBottomSheet={closeNationalIdBottomSheet}
          openNationalIdBottomSheet={openNationalIdBottomSheet}
        />
      )}
    </>
  );
}
