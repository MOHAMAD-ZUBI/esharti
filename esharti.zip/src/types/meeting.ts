export type meetingProps = {
  id: number;
  admin_id: number;
  plan_id: number;
  related_id: number;
  meeting_id: string;
  password: string;
  encrypted_password: string;
  join_url: string;
};
