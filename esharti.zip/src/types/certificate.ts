export type certificateProps = {
  id: number;
  file_pdf: string;
  related: {
    title: string;
    id: number;
  };
};
