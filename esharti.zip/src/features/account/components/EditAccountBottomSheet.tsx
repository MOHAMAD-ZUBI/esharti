import React, { Ref } from "react";
import EditAccountForm from "./EditAccountForm";
import { ChatAltBlackIcon } from "../../../components/SvgIcons";
import { BottomSheet, bottomSheetRef } from "../../bottomSheet";
import { ScrollView } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { BottomSheetModal } from "@gorhom/bottom-sheet";

type EditAccountBottomSheetProps = {
  bottomSheetRef: Ref<BottomSheetModal>;
  closeEditAccountBottomSheet: () => void;
  openSuccessModal: (message: string) => void;
};

const EditAccountBottomSheet: React.FC<EditAccountBottomSheetProps> = ({
  bottomSheetRef,
  openSuccessModal,
  closeEditAccountBottomSheet,
}) => {
  const { editProfileStatus } = useLocalSearchParams();
  const onModalHide = () => {
    if (editProfileStatus === "success") {
      openSuccessModal("تم تحديث المعلومات بنجاح");
    }
  };
  return (
    <BottomSheet
      onModalHide={onModalHide}
      headerTitle="تعديل بيانات الحساب"
      headerIcon={<ChatAltBlackIcon />}
      bottomSheetRef={bottomSheetRef}
    >
      <EditAccountForm
        closeEditAccountBottomSheet={closeEditAccountBottomSheet}
      />
    </BottomSheet>
  );
};

export default EditAccountBottomSheet;
