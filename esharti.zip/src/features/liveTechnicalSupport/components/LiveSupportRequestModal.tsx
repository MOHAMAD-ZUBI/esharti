import { View, Text } from "react-native";
import React from "react";

type Props = {};

const LiveSupportRequestModal = (props: Props) => {
  return (
    <View>
      <Text>LiveSupportRequestModal</Text>
    </View>
  );
};

export default LiveSupportRequestModal;
