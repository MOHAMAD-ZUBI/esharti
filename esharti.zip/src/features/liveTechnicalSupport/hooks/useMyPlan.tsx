import { useSuspenseQuery } from "@tanstack/react-query";
import { authRoutes } from "../../../routes";
import { API } from "../../../lib/client";
import { useAuth } from "../../../context/AuthContext";
import { myPlanProps } from "../../../types/myPlan";

export const fetchMyPlans = async () => {
  const { data } = await API.get(authRoutes.getMyPlans);
  return data.data;
};

export default function useMyPlans() {
  const { session } = useAuth();

  return useSuspenseQuery<myPlanProps[]>({
    queryKey: ["myPlans", session?.authenticated],
    queryFn: fetchMyPlans,
    gcTime: 0,
  });
}
