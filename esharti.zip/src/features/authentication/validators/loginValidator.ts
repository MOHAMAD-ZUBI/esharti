import { z } from "zod";

const LoginValidator = z.object({
  email: z
    .string({ required_error: "الرجاء إدخال الايميل" })
    .email({ message: "الإيميل المدخل غير صحيح" }),
  password: z
    .string({ required_error: "الرجاء إدخال الباسورد" })
    .min(1, { message: "الرجاء إدخال الباسورد" }),
});

type LoginCredentials = z.infer<typeof LoginValidator>;

export { LoginCredentials, LoginValidator };
