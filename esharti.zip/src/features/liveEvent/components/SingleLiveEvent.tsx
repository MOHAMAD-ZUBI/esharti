import React, { useState } from "react";
import { router, useLocalSearchParams } from "expo-router";
import {
  ArrowLeftIcon,
  BadgeCheckIcon,
  CashIcon,
  TimeIcon,
} from "../../../components/SvgIcons";
import { TouchableOpacity } from "react-native-gesture-handler";
import { Image } from "expo-image";
import { View } from "../../../components/custom/View";
import { ActivityIndicator, ScrollView } from "react-native";
import { Badge } from "../../courses";
import InformationCard from "./InformationCard";
import { Text } from "../../../components/custom/Text";
import useSingleLiveEvent from "../hooks/useSingleLiveEvent";
import useLiveEventPayment from "../hooks/useLiveEventPayment";
import { useAuth } from "../../../context/AuthContext";
import { API } from "../../../lib/client";
import { authRoutes } from "../../../routes";
import Moment from "moment";

const SingleLiveEvent = () => {
  const { liveEventId } = useLocalSearchParams();
  const { data } = useSingleLiveEvent(String(liveEventId));
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSameOrAfter] = useState(
    Moment(Date.now()).isSameOrAfter(data.event_at)
  );
  const { session } = useAuth();
  const { mutate: paymentHandler, isPending } = useLiveEventPayment(
    Number(liveEventId)
  );

  const onPress = async () => {
    if (!session?.authenticated) return router.push("/auth/");
    if (data?.is_paid && data?.purchased === false) {
      paymentHandler();
    }
    if (data?.is_paid === false && data?.purchased === false) {
      setIsLoading(true);
      try {
        await API.post(authRoutes.buyLiveEvent, { liveEvent_id: data?.id });
      } finally {
        setIsLoading(false);
        router.replace({
          pathname: "/paymentSuccess",
          params: {
            navigateTo: `/liveEvent?liveEventId=${liveEventId}`,
            paymentType: "freeLiveEvent",
          },
        });
      }
    }

    if (data?.meeting_info) {
      router.push({
        pathname: "/zoom",
        params: {
          meetingId: data.meeting_info.meeting_id,
          meetingPassword: data.meeting_info.encrypted_password,
        },
      });
    }
  };

  const isDisabled = () => {
    if (!data.purchased) return false;
    if (isSameOrAfter && data.meeting_info) {
      return false;
    }
    if (data.meeting_info && !isSameOrAfter) return true;
    if (!data.meeting_info && !isSameOrAfter) return true;
  };
  return (
    <ScrollView showsVerticalScrollIndicator={false} className="bg-[#F5F5F5]">
      <View shadowVariant="small" className="bg-white mx-layout rounded-xl">
        {data?.image ? (
          <Image
            source={{ uri: data?.image }}
            className="h-[194px] w-full rounded-t-xl mb-[15px]"
          />
        ) : (
          <Image
            source={require("../../../assets/images/LiveEventImage.png")}
            className="h-[194px] w-full rounded-t-xl mb-[15px]"
          />
        )}
        <View className="mx-[12px]">
          <View className="flex-row items-center space-x-[6px] mb-5">
            <View>
              {data?.purchased ? (
                <Badge
                  variant="withIcon"
                  backgroundColor="#E7FFF9"
                  textColor="#25B896"
                  Icon={BadgeCheckIcon}
                  title={"انت مشترك في هذه الندوة"}
                />
              ) : (
                <Badge
                  variant="withIcon"
                  Icon={CashIcon}
                  title={data.price ? String(data.price) + " ريال" : "مجاناً"}
                />
              )}
            </View>
            <View>
              <Badge
                variant="withIcon"
                Icon={TimeIcon}
                title={data?.duration_event}
              />
            </View>
          </View>
          <InformationCard
            presenter={data?.event_presenter}
            date={data?.event_at}
          />
          <View className="mt-5">
            <Text className="text-[20px]">{data?.name}</Text>
            <Text className="text-[#525252]" fontWeight="400">
              {data?.description}
            </Text>
          </View>
          <View className="mt-[32px] mb-[12px]">
            <TouchableOpacity
              disabled={isDisabled()}
              onPress={onPress}
              className={`bg-primary flex-row justify-between items-center rounded-xl py-3 px-4`}
            >
              {isLoading && <ActivityIndicator size="small" color={"white"} />}
              {isPending && <ActivityIndicator size="small" color={"white"} />}
              {!isLoading && !isPending && (
                <Text className="text-[16px]" fontWeight="500">
                  {data?.purchased ? "شاهد الأن" : "سجل الأن"}
                </Text>
              )}
              {!isLoading && !isPending && <ArrowLeftIcon />}
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default SingleLiveEvent;
