import SmallCourseCard from "./CourseCardVariants/SmallCourseCard";
import MediumCourseCard from "./CourseCardVariants/MediumCourseCard";
import LargeCourseCard from "./CourseCardVariants/LargeCourseCard";
import { courseProps } from "../../../types/course";

type cousreCardProps = {
  showSubscribeButton?: boolean;
  totalLessonTime?: string;
  variant: "small" | "medium" | "large";
} & courseProps;

const CourseCard = ({
  variant = "small",
  totalLessonTime,
  ...restProps
}: cousreCardProps) => {
  return (
    <>
      {variant === "small" && <SmallCourseCard {...restProps} />}
      {variant === "medium" && <MediumCourseCard {...restProps} />}
      {variant === "large" && (
        <LargeCourseCard {...restProps} totalLessonTime={totalLessonTime} />
      )}
    </>
  );
};

export default CourseCard;
