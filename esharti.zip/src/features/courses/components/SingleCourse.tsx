import { View, Text, ActivityIndicator, Share } from "react-native";
import React, { useEffect, useLayoutEffect } from "react";
import { ScrollView, TouchableOpacity } from "react-native-gesture-handler";
import useSingleCourse from "../hooks/useSingleCourse";
import CourseCard from "./CourseCard";
import { LessonList, useLessons } from "../../lessons";
import {
  ArrowLeftIcon,
  ShareIcon,
  WhiteAcademicCapIcon,
  WhiteArrowLeftIcon,
} from "../../../components/SvgIcons";
import { router, usePathname } from "expo-router";
import Bookmark from "../../../components/Bookmark";
import useCoursePayment from "../hooks/useCoursePayment";
import { useAuth } from "../../../context/AuthContext";
import ShareButton from "../../../components/ShareButton";
import moment from "moment";
const SingleCourse = ({ courseId }: { courseId: string }) => {
  const { data: course, isLoading, refetch, error } = useSingleCourse(courseId);

  const { data: lessons } = useLessons(courseId);

  const path = usePathname();
  const { session } = useAuth();
  useEffect(() => {
    const allCompleted = lessons.every((lesson) => lesson.completed);
    if (allCompleted && course.completed === false) {
      refetch();
    }
  }, [lessons]);

  const convertToMinutes = (time: string) => {
    const [minutes, seconds] = time.split(":").map(Number);
    return minutes;
  };

  const totalLessonTime = lessons?.reduce((total, lesson) => {
    return total + convertToMinutes(lesson.lesson_time!);
  }, 0);

  const { mutate: paymentHandler, isPending } = useCoursePayment(
    Number(courseId)
  );
  return (
    <View className="flex-1 justify-between">
      <View className="flex-row items-center justify-between  my-[23px] mx-[18px]">
        <View className="flex-row items-center gap-[10px]">
          <View>
            <Bookmark
              id={String(course?.id)}
              variant="course"
              bookmarked={course?.bookmarked}
            />
          </View>
          <View>
            <ShareButton
              description={course?.description}
              title={course?.title}
            />
          </View>
        </View>
        <TouchableOpacity onPress={() => router.replace("/courses/")}>
          <ArrowLeftIcon />
        </TouchableOpacity>
      </View>
      <ScrollView
        scrollEnabled={!isLoading}
        showsVerticalScrollIndicator={false}
        className="mx-[18px]"
      >
        <CourseCard
          variant="large"
          {...course}
          totalLessonTime={String(totalLessonTime)}
        />

        {!isLoading && (
          <LessonList courseId={courseId} subscribed={course?.subscribed} />
        )}
      </ScrollView>

      {!course?.subscribed && (
        <TouchableOpacity
          disabled={isPending}
          onPress={() =>
            session?.authenticated
              ? paymentHandler()
              : router.push({
                  pathname: "/auth/",
                  params: { navigatedFrom: path },
                })
          }
          className=" w-full "
        >
          <View className="mx-[18px]  bg-primary h-[59px] justify-center  px-4 rounded-xl">
            {isPending ? (
              <ActivityIndicator size={"small"} color={"white"} />
            ) : (
              <View className="flex-row justify-between items-center ">
                <Text className="text-[18px]">اشترك الأن</Text>
                <ArrowLeftIcon />
              </View>
            )}
          </View>
        </TouchableOpacity>
      )}
      {course?.subscribed && (
        <TouchableOpacity
          disabled={!course.completed}
          onPress={() => router.push("/certificates")}
          className=""
        >
          <View
            style={{ backgroundColor: course?.completed ? "black" : "#B3B3B3" }}
            className="mx-[18px] flex-row justify-between bg-black h-[59px] items-center  px-4 rounded-xl"
          >
            <View className="flex-row items-center gap-3">
              <WhiteAcademicCapIcon />
              <Text className="text-[18px] text-[#F5F5F5]">
                احصل على شهادة إكمال الدورة
              </Text>
            </View>
            <WhiteArrowLeftIcon />
          </View>
        </TouchableOpacity>
      )}
    </View>
  );
};

export default SingleCourse;
