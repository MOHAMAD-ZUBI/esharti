import { ScrollView } from "react-native";
import { View } from "../../../components/custom/View";
import useCourses from "../hooks/useCourses";
import CourseCard from "./CourseCard";
import useSuggestedCourses from "../hooks/useSuggestedCourses";

const SuggestedCoursesList = () => {
  const { data } = useSuggestedCourses();
  return (
    <View className="">
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{
          paddingTop: 8,
          paddingBottom: 20,
          flexGrow: 1,
        }}
        className="ml-layout"
      >
        {data?.map((course) => (
          <CourseCard
            variant="small"
            key={course.id}
            {...course}
            duration={"50 دقيقة"}
          />
        ))}
      </ScrollView>
    </View>
  );
};

export default SuggestedCoursesList;
