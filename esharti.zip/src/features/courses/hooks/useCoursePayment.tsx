import { useMutation, useQueryClient } from "@tanstack/react-query";
import { authRoutes } from "../../../routes";
import { API } from "../../../lib/client";
import { router } from "expo-router";
import { useAuth } from "../../../context/AuthContext";

export default function useCoursePayment(course_id: number) {
  const queryClient = useQueryClient();
  const { session } = useAuth();
  return useMutation({
    mutationFn: async () => {
      try {
        const { data } = await API.post(authRoutes.paidCourseSubscription, {
          course_id,
        });
        return data.data;
      } catch (error: any) {
        throw new Error(error?.response?.data?.errors);
      }
    },
    onSuccess: (data) => {
      router.push({
        pathname: "/payment",
        params: {
          paymentUri: data?.responseResult?.payment_url,
          navigatedFrom: "course",
          id: course_id,
        },
      });
    },
    onError: (error) => {
      console.log(error);
    },
  });
}
